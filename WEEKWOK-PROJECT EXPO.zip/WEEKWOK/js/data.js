/* Data + state. All quantities are stored in base units: g, ml or pcs. */
const DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
const MEALS = ['Breakfast','Lunch','Dinner'];
const $ = s => document.querySelector(s);

const AISLES = ['Produce','Dairy & Eggs','Grains & Flour','Pantry & Spices','Bakery','Other'];
const AISLE = {onion:'Produce',tomato:'Produce',potato:'Produce',peas:'Produce',spinach:'Produce',
  paneer:'Dairy & Eggs',milk:'Dairy & Eggs',curd:'Dairy & Eggs',eggs:'Dairy & Eggs',butter:'Dairy & Eggs',
  rice:'Grains & Flour',basmati:'Grains & Flour',flour:'Grains & Flour',poha:'Grains & Flour',
  oil:'Pantry & Spices',dal:'Pantry & Spices',gm:'Pantry & Spices',cumin:'Pantry & Spices',gg:'Pantry & Spices',bread:'Bakery'};

// id, name, unit, stock, low-stock threshold, price (₹ per 100 g/ml, or per piece), expiry in days, emoji
const ING = [
  ['rice','Rice','g',2000,500,9,null,'🍚'],['basmati','Basmati Rice','g',100,300,15,null,'🍚'],
  ['flour','Wheat Flour','g',1000,300,5,null,'🌾'],['oil','Cooking Oil','ml',1000,200,18,null,'🛢️'],
  ['onion','Onions','g',500,200,4,null,'🧅'],['tomato','Tomatoes','g',400,200,4,4,'🍅'],
  ['potato','Potatoes','g',600,200,3,null,'🥔'],['paneer','Paneer','g',200,200,35,2,'🧀'],
  ['peas','Green Peas','g',0,100,12,null,'🟢'],['milk','Milk','ml',1000,500,6,2,'🥛'],
  ['curd','Curd','g',400,200,8,3,'🥣'],['eggs','Eggs','pcs',6,4,7,10,'🥚'],
  ['butter','Butter','g',100,50,55,20,'🧈'],['dal','Toor Dal','g',500,200,14,null,'🫘'],
  ['spinach','Spinach','g',200,100,6,1,'🥬'],['gm','Garam Masala','g',100,20,60,null,'🌶️'],
  ['cumin','Cumin Seeds','g',100,20,40,null,'🌿'],['gg','Ginger-Garlic Paste','g',150,50,15,null,'🧄'],
  ['bread','Bread','pcs',8,4,5,3,'🍞'],['poha','Poha','g',500,200,8,null,'🍘']
].map(([id,name,unit,stock,min,price,exp,emoji]) => ({id,name,unit,stock,min,price,exp,emoji,aisle:AISLE[id]||'Other'}));
const I = Object.fromEntries(ING.map(i => [i.id, i]));

// id, name, emoji, prep minutes, serves, ingredients {id: qty in base unit}
const REC = Object.fromEntries([
  ['pulao','Vegetable Pulao','🍛',35,4,{basmati:300,peas:100,onion:100,oil:30,cumin:5,gm:5}],
  ['pbm','Paneer Butter Masala','🧈',30,4,{paneer:400,tomato:300,butter:30,onion:100,gm:5,gg:15}],
  ['dal','Dal Tadka','🍲',30,4,{dal:200,onion:80,tomato:100,oil:20,cumin:5,gg:10}],
  ['aloop','Aloo Paratha','🫓',40,3,{flour:400,potato:300,oil:30,curd:100}],
  ['bhurji','Egg Bhurji','🍳',15,2,{eggs:4,onion:100,tomato:50,oil:15}],
  ['poha','Poha','🍘',20,3,{poha:200,onion:100,potato:100,peas:30,oil:20}],
  ['palak','Palak Paneer','🥬',30,4,{paneer:250,spinach:300,onion:80,oil:20,gg:10}],
  ['jeera','Jeera Rice','🍚',20,3,{rice:300,cumin:5,oil:15}],
  ['curdrice','Curd Rice','🥣',20,3,{rice:250,curd:300}],
  ['sandwich','Veg Sandwich','🥪',15,2,{bread:6,butter:20,tomato:100,onion:50,potato:100}],
  ['rotisabzi','Roti Sabzi','🫓',35,4,{flour:300,potato:300,onion:80,oil:20,gm:3}],
  ['omelette','Masala Omelette','🍳',10,2,{eggs:3,onion:50,oil:10,bread:2}],
  ['khichdi','Dal Khichdi','🍲',30,4,{rice:200,dal:100,oil:15,cumin:3}],
  ['alumatar','Aloo Matar','🥔',30,4,{potato:300,peas:150,tomato:100,oil:20,gm:5}],
  ['kheer','Rice Kheer','🍮',40,4,{rice:100,milk:500}]
].map(([id,name,emoji,prep,serves,ing]) => [id,{id,name,emoji,prep,serves,ing}]));

/* ---------- state ---------- */
const dateIn = n => { const d = new Date(); d.setDate(d.getDate()+n); return d.toISOString().slice(0,10); };
const seed = () => ({ p: Object.fromEntries(ING.map(i => [i.id, {stock:i.stock, exp:i.exp===null?null:dateIn(i.exp)}])), plan:{} });
let S = null;
try { S = JSON.parse(localStorage.getItem('weekwok')); } catch (e) { console.warn('Saved data unreadable, starting fresh.'); }
if (!S || typeof S !== 'object' || !S.p) S = seed();
S.plan = S.plan || {};
S.custom = S.custom || {ings:[], recs:[]};
ING.forEach(i => { if (!S.p[i.id]) S.p[i.id] = {stock:i.stock, exp:i.exp===null?null:dateIn(i.exp)}; });

/* custom (user-added) data */
function registerIng(i) {
  if (I[i.id]) return;
  ING.push(i); I[i.id] = i;
  if (!S.p[i.id]) S.p[i.id] = {stock:i.stock, exp:i.expDate || null};
}
function registerRec(r) { REC[r.id] = r; }
function registerAll() {
  S.custom.ings.filter(i => NAME_RE.test(i.name)).forEach(registerIng);
  S.custom.recs.filter(r => NAME_RE.test(r.name)).forEach(registerRec);
}
const save = () => {
  try {
    localStorage.setItem('weekwok', JSON.stringify(S));
  } catch (e) {
    if (typeof toast === 'function') toast('⚠ Could not save changes (storage full or blocked)', true);
  }
};

/* ---------- helpers ---------- */
const fmt = (q,u) => u==='pcs' ? q+' pcs' : q>=1000 ? parseFloat((q/1000).toFixed(2))+(u==='g'?' kg':' L') : q+' '+u;
const cost = (id,q) => I[id].price * (I[id].unit==='pcs' ? q : q/100);
const daysLeft = exp => Math.round((new Date(exp+'T00:00') - new Date(new Date().toDateString())) / 864e5);
const slotKey = (d,m) => d+'-'+m;