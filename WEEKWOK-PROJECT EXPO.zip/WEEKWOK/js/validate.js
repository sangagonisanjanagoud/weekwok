/* Input validation for user-entered pantry items and recipes. */
const NAME_RE = /^[\p{L}\p{N} '\-]{2,30}$/u;
const UNITS = ['g', 'ml', 'pcs'];

const clean = v => String(v == null ? '' : v).trim().replace(/\s+/g, ' ');
const num = (v, min, max) => {
  const n = Number(v);
  return v !== '' && v != null && Number.isFinite(n) && n >= min && n <= max ? n : null;
};
const slug = n => n.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'item';
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 5);

function validateIngredient(f, existing = ING) {
  const e = [], name = clean(f.name);
  if (!NAME_RE.test(name)) e.push("Name must be 2–30 characters: letters, numbers, spaces, - or '.");
  else if (existing.some(i => i.name.toLowerCase() === name.toLowerCase())) e.push('That item already exists.');

  if (!UNITS.includes(f.unit)) e.push('Choose a valid unit.');
  const stock = num(f.stock, 0, 1e5), min = num(f.min, 0, 1e5), price = num(f.price, 0, 1e5);
  if (stock === null) e.push('Stock must be a number from 0 to 100000.');
  if (min === null) e.push('Low-stock level must be a number from 0 to 100000.');
  if (price === null) e.push('Price must be a number from 0 to 100000.');
  if (!AISLES.includes(f.aisle)) e.push('Choose a valid aisle.');

  const expDate = f.expDate || null;
  if (expDate && (!/^\d{4}-\d{2}-\d{2}$/.test(expDate) || isNaN(new Date(expDate)))) {
    e.push('Expiry date is not valid.');
  }

  return {
    ok: !e.length,
    errors: e,
    value: {
      id: 'c_' + slug(name) + '_' + uid(),
      name, unit: f.unit, stock, min, price, exp: null,
      emoji: '🛒', aisle: f.aisle, expDate
    }
  };
}

/* Ingredient lines can look like "Paneer 400g", "Rice 1 kg", or "Eggs 4". */
function validateRecipe(f, ingList = ING, recs = REC) {
  const e = [], name = clean(f.name), ing = {};
  if (!NAME_RE.test(name)) e.push("Recipe name must be 2–30 characters: letters, numbers, spaces, - or '.");
  else if (Object.values(recs).some(r => r.name.toLowerCase() === name.toLowerCase())) {
    e.push('A recipe with that name already exists.');
  }

  const prep = num(f.prep, 1, 600), serves = num(f.serves, 1, 50);
  if (prep === null || !Number.isInteger(prep)) e.push('Prep time must be a whole number of minutes (1–600).');
  if (serves === null || !Number.isInteger(serves)) e.push('Servings must be a whole number (1–50).');

  String(f.ingText || '').split('\n').map(l => l.trim()).filter(Boolean).forEach(l => {
    const m = l.match(/^(.+?)\s+(\d+(?:\.\d+)?)\s*(kg|g|l|ml|pcs)?$/i);
    const it = m && ingList.find(i => i.name.toLowerCase() === m[1].trim().toLowerCase());
    if (!it) return e.push(`Can't read "${l.slice(0, 40)}". Use "Name amount" with an item from your pantry.`);

    let q = Number(m[2]);
    const u = (m[3] || '').toLowerCase();
    if ((u === 'kg' && it.unit === 'g') || (u === 'l' && it.unit === 'ml')) q *= 1000;
    else if (u && u !== it.unit) return e.push(`${it.name} is measured in ${it.unit}.`);
    if (q <= 0 || q > 1e5) return e.push(`Amount for ${it.name} is out of range.`);
    ing[it.id] = (ing[it.id] || 0) + q;
  });

  if (!Object.keys(ing).length && !e.length) e.push('Add at least one ingredient.');

  return {
    ok: !e.length,
    errors: e,
    value: { id: 'r_' + slug(name) + '_' + uid(), name, emoji: '🍽️', prep, serves, ing }
  };
}